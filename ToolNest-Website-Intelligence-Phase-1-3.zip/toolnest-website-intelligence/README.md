# ToolNest — Website Intelligence Command Center

Private/internal project. Phase 1–3 foundation is included.

## Phase 1 — Foundation
Next.js dashboard, domain validation, audit API, verified/calculated/source-status model.

## Phase 2 — Technical Crawl
Same-origin crawler, HTTP status checks, redirects, broken/error detection, title/meta/H1/canonical/robots extraction, internal link discovery, crawl limits and timeouts.

## Phase 3 — Technical SEO Dashboard
Health score, severity findings, crawl summary, source status, responsive dashboard.

## Later phases
PageSpeed/Core Web Vitals, GSC, GA4, DNS, security, images, schema, backlink providers, competitors, content, internal-link graph, historical audits, AI analyst and exports.

No external metric is fabricated. A source remains “not connected” until its real API is configured.
