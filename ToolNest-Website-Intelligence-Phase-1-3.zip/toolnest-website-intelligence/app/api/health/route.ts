import {NextResponse} from 'next/server';export async function GET(){return NextResponse.json({ok:true,service:'toolnest-website-intelligence',time:new Date().toISOString()})}
