export type Severity='critical'|'high'|'medium'|'low';
export type Issue={severity:Severity;code:string;title:string;detail:string;url?:string};
export type Page={url:string;status:number|null;title:string;description:string;h1:number;canonical:string;wordCount:number;internalLinks:number;error?:string};
export type Audit={domain:string;pagesScanned:number;pages:Page[];issues:Issue[];score:number;sources:{name:string;status:'verified'|'calculated'|'not_connected'}[]};
